/**

 */
#pragma once





// Single extruder printer?
//#define MT_IF_ONLY_ONE_EXTRUDER




//
// The following parameters do not need to be set
//

//#define SERIAL_PORT -1
//#define SERIAL_PORT_2 1


#define MULTOO_UNIFIED_MODE


#define MULTOO_UNIFIED_VERSION ".12"

#ifdef MULTOO_UNIFIED_MODE

#define MULTOO_MODE_DXC
//#define MULTOO_MODE_STA

#endif


#define MULTOO_NOZZLE_COUNT  2


/**
 * General function settings
 */
// High temperature module-use PT100 detection module
//#define TEMP_SENSOR_USE_PT100_MKS     // MKS
//#define TEMP_SENSOR_USE_PT100_UB      // ULTIMAKER
//#define TEMP_SENSOR_USE_PT100_BTT     // BIGTREE

// Printer size setting
#define PRINT_SIZE_500x500x500
//#define PRINT_SIZE_500x500x600
//#define PRINT_SIZE_500x500x700
//#define PRINT_SIZE_500x500x800



/**
 * ****************************** The following are fixed functions. It's already set up. **************************
 * MULTOO_HAS_LASER_FUNTION
 * MULTOO_USE_AUTO_LEVEVLING
 * MULTOO_ADVANCE_SPEED
 * MULTOO_AUTO_POWER_OFF
 * Z_START_POS_STORAGE
 */


#if MULTOO_NOZZLE_COUNT == 1
#define MODE_ONLY_ONE_EXTRUDER
#elif MULTOO_NOZZLE_COUNT == 2
#define MODE_HAS_TWO_EXTRUDERS
#endif



#ifdef MULTOO_MODE_DXC

#define MULTOO_HAS_LASER_FUNTION
#define MULTOO_USE_AUTO_LEVEVLING
#define MULTOO_ADVANCE_SPEED
//#define MULTOO_AUTO_POWER_OFF
#define Z_START_POS_STORAGE


#define MACHINE_NAME "MT3X"
#define USE_XMAX_PLUG
#define X2_DRIVER_TYPE TMC2209
#define NO_LCD_MENUS


#endif




/**
 * If there is only one extruder
 * Turn off extruder E2.
 * Turn off the function of the dual extruder
 */

#ifdef MULTOO_MODE_STA

#define MULTOO_HAS_LASER_FUNTION
#define MULTOO_USE_AUTO_LEVEVLING
#define MULTOO_ADVANCE_SPEED
#define MULTOO_AUTO_POWER_OFF
#define Z_START_POS_STORAGE


#define MACHINE_NAME "MT3S"
#define MACHINE_TYPE_MT3S
#define NO_LCD_MENUS

#endif

// Invert the stepper direction. Change (or reverse the motor connector) if an axis goes the wrong way.
#define INVERT_X_DIR false

#ifdef MULTOO_MODE_STA
#define INVERT_Y_DIR false
#endif

#ifdef MULTOO_MODE_DXC
#define INVERT_Y_DIR true
#endif

#define INVERT_Z_DIR false
#define INVERT_E0_DIR true
#define INVERT_E1_DIR false


/**
 * Stepper Drivers
 */
#define X_DRIVER_TYPE  TMC2209
#define Y_DRIVER_TYPE  A4988
#define Z_DRIVER_TYPE  TMC2209
#define E0_DRIVER_TYPE TMC2209
#define E1_DRIVER_TYPE TMC2209



/**
 * Temperature Sensor
 */
#ifdef TEMP_SENSOR_USE_PT100_MKS
#define TEMP_SENSOR_0 10
#define HEATER_0_MAXTEMP 415
#elif defined(TEMP_SENSOR_USE_PT100_UB)
#define TEMP_SENSOR_0 21
#define HEATER_0_MAXTEMP 415
#elif defined(TEMP_SENSOR_USE_PT100_BTT)
#define TEMP_SENSOR_0 21
#define HEATER_0_MAXTEMP 415
#else // ntc100k
#define TEMP_SENSOR_0 1
#define HEATER_0_MAXTEMP 275
#endif

#ifdef MODE_HAS_TWO_EXTRUDERS 
#ifdef TEMP_SENSOR_USE_PT100_MKS
#define TEMP_SENSOR_1 10
#define HEATER_1_MAXTEMP 415
#elif defined(TEMP_SENSOR_USE_PT100_UB)
#define TEMP_SENSOR_1 21
#define HEATER_1_MAXTEMP 415
#elif defined(TEMP_SENSOR_USE_PT100_BTT)
#define TEMP_SENSOR_1 21
#define HEATER_1_MAXTEMP 415
#else // ntc100k
#define TEMP_SENSOR_1 1
#define HEATER_1_MAXTEMP 275
#endif
#else
#define TEMP_SENSOR_1 0
#define HEATER_1_MAXTEMP 275
#endif



#ifdef MULTOO_MODE_DXC
#define X_HOME_DIR 1
#else
#define X_HOME_DIR -1
#endif


#ifdef PRINT_SIZE_500x500x500
#define X_BED_SIZE 500
#define Y_BED_SIZE 500
#define Z_BED_SIZE 500
#elif defined(PRINT_SIZE_500x500x600)
#define X_BED_SIZE 500
#define Y_BED_SIZE 500
#define Z_BED_SIZE 600
#elif defined(PRINT_SIZE_500x500x700)
#define X_BED_SIZE 500
#define Y_BED_SIZE 500
#define Z_BED_SIZE 700
#elif defined(PRINT_SIZE_500x500x800)
#define X_BED_SIZE 500
#define Y_BED_SIZE 500
#define Z_BED_SIZE 800
#else
#define X_BED_SIZE 200
#define Y_BED_SIZE 200
#define Z_BED_SIZE 200
#endif




/**
 * Auto bed leveling
 */
#ifdef MULTOO_USE_AUTO_LEVEVLING
#define BLTOUCH
#define AUTO_BED_LEVELING_BILINEAR
#define BLTOUCH_SET_5V_MODE
#endif  // MULTOO_USE_AUTO_LEVEVLING


#ifndef MULTOO_MODE_DXC
#define MAX_SOFTWARE_ENDSTOPS
#define MIN_SOFTWARE_ENDSTOPS
#endif




/**
 * Multoo Dual X Carriage
 *
 * This setup has two X carriages that can move independently, each with its own hotend.
 * The carriages can be used to print an object with two colors or materials, or in
 * "duplication mode" it can print two identical or X-mirrored objects simultaneously.
 * The inactive carriage is parked automatically to prevent oozing.
 * X1 is the left carriage, X2 the right. They park and home at opposite ends of the X axis.
 * By default the X2 stepper is assigned to the first unused E plug on the board.
 *
 * 
 *      HOME POSITION STATUS
 * 
 *     L2    L6                            X_BED_SIZE                              L6   L3
 *    -moto-|--|===E===|-------------|---------BED----------|-------------|===E===|--|-moto-
 *                                 (0,0)                  (0,500)
 *             |-L4-|----offset-l----|                      |----offset-r----|-L5-|
 *                  ^                                                        ^
 *                  |------------- MAX_EXTRUDER_ACTIVITY_SPACE --------------|
 *                nozzle                                                   nozzle
 *                          
 *      L1, Length of X-axis aluminum profile
 *      L2, Length of leftside-x-moto-base
 *      L3, Length of rightside-x-moto-base
 *      L4, Length between left-extruder-leftside and left-extruder-nozzle
 *      L5, Length between right-extruder-rightside and right-extruder-nozzle
 *      L6, Offset of between limit and extruder-leftside or extruder-rightside
 * 
 *      parkinglot-left-extruder, left-extruder-nozzle-offset-to-bed(0,0), adjustable, offset-l, Negative value
 *      parkinglot-right-extruder, offset-r, Positive value
 *      offset-r = L1 - L2 - L3 - 2*L6 - L4 - L5 - X_BED_SIZE + offset-l
 *      or,
 *      offset-r = MAX_EXTRUDER_ACTIVITY_SPACE + offset-l
 * 
 * The following Dual X Carriage modes can be selected with M605 S<mode>:
 *      
 * STANDARD
 *  - GENNAL
 *  - INTERVAL
 *  - AUTO_INTERVAL
 *  - MIRROR
 * 
 * DUPLICATION
 *  - GENNAL
 *  - MIRROR
 */

#ifdef MULTOO_MODE_DXC
    #define MAX_EXTRUDER_ACTIVITY_SPACE     628.0           // Must be set! The furthest distance between nozzles    

    // Suppose the value of X_BED_SIZE is 500.0    
    // right extruder,T0, The range of values is (0 ~ 500 + X1_OFFSET_FROM_MAX_POS)
    #define X1_OFFSET_FROM_MAX_POS          65.0            // Must be set! == offset-r, Positive value
    #define X1_MIN_POS                      X_MIN_POS       // Must be set! == 0.0
    #define X1_MAX_POS                      (X_BED_SIZE + X1_OFFSET_FROM_MAX_POS)       // Must be set! 

    // left extruder,T1, The range of values is (X2_MIN_POS ~ 500)
    #define X2_MIN_POS                      X1_MAX_POS - MAX_EXTRUDER_ACTIVITY_SPACE          // Must be set! == offset-l, Negative value
    #define X2_MAX_POS                      X_BED_SIZE        // Must be set! Set this to the distance between toolheads when both heads are homed
    // Direction of endstops when homing; 1=MAX, -1=MIN
    #define X2_HOME_DIR                     -1                // Must be set! Set to -1. The second X-carriage always homes to the minimum endstop position
    #define X2_HOME_POS                     X2_MIN_POS        // Must be set!

    // ---------------------------------------------------------------------------
    // !!!! Must undefine  MIN_SOFTWARE_ENDSTOPS   MAX_SOFTWARE_ENDSTOPS !!!!    |
    // ---------------------------------------------------------------------------

    // However, these settings are theoretical values, and we need to make the coordinates (0,0) adjustable.
    // The value of MAX_EXTRUDER_ACTIVITY_SPACE does not need to be set to be adjustable. Because once it is set successfully, there is no need to set it again.

    // This is the default power-up mode which can be later using M605.
    #define DEFAULT_DUAL_X_CARRIAGE_MODE DXC_STANDARD_MODE
    // Default x offset in duplication mode (typically set to half print bed width)
    #define DEFAULT_DUPLICATION_X_OFFSET X_BED_SIZE/2

#endif // MULTOO_MODE_DXC










//#endif // MULTOO_UNIFIED_MODE

/**
 * PS_ON_PIN, turn off power, M81
 * 
 * detected,POWER_LOSS_RECOVERY
 * POWER_LOSS_PIN
 * 
 */
